<h3
    <?php echo e($attributes->class(['fi-section-header-heading font-semibold leading-6 text-gray-950 dark:text-white text-2xl'])); ?>

>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH C:\Users\luigi\OneDrive\Desktop\appauto\vendor\eightynine\filament-advanced-widgets\src\/../resources/views/components/section/heading.blade.php ENDPATH**/ ?>