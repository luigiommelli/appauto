<p
    <?php echo e($attributes->class(['fi-section-header-description overflow-hidden break-words text-xs text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\Users\luigi\OneDrive\Desktop\appauto\vendor\eightynine\filament-advanced-widgets\src\/../resources/views/components/section/description.blade.php ENDPATH**/ ?>