<?php

namespace App\Filament\Resources\ArchivedVehicleResource\Pages;

use App\Filament\Resources\ArchivedVehicleResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateArchivedVehicle extends CreateRecord
{
    protected static string $resource = ArchivedVehicleResource::class;
}
