<?php

namespace App\Filament\Resources\SoldVehicleResource\Pages;

use App\Filament\Resources\SoldVehicleResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSoldVehicle extends CreateRecord
{
    protected static string $resource = SoldVehicleResource::class;
}
