<?php

namespace App\Filament\Resources\InArrivoVehicleResource\Pages;

use App\Filament\Resources\InArrivoVehicleResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInArrivoVehicle extends CreateRecord
{
    protected static string $resource = InArrivoVehicleResource::class;
}
