<?php

namespace App\Filament\Resources\AvailableVehicleResource\Pages;

use App\Filament\Resources\AvailableVehicleResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAvailableVehicle extends CreateRecord
{
    protected static string $resource = AvailableVehicleResource::class;
}
